import Notice from "./Notice";

export const NoticeProductInfo = () => {
  return (
    <div>
      <Notice />
    </div>
  );
};
